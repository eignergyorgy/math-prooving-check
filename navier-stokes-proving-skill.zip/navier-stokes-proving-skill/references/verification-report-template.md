# Verification report template (one page)

Rules:
- One page. Tables over prose. No praise, no narrative of the work done.
- Write the report in the user's language; keep verdict labels and relation codes in English.
- Every claim in the report must point to an artifact location (file:line / declaration / test name) or to TS-v<k>.
- If a section has nothing to report, write "none" - never omit the section.

---

```
VERIFICATION REPORT - <short target name>
Date: <YYYY-MM-DD>   Target: TS-v<k> (frozen <date>)   Task type: (i) proof translation | (ii) faithful translation
Tools & versions: <Lean x.y + Mathlib commit | MATLAB R20xx + toolboxes | Wolfram vx | language + test framework>
Artifacts: <files / declarations / commit>

T1 verbatim target:
  "<exact statement / requirement as approved>"

1. VERDICT: <FAITHFUL | PROOF-CHANGED | STATEMENT-CHANGED | UNDECIDED | NOT PROVEN>
   One-line reason: <...>
   Independent audit: run on <date> | declined by user (verdict capped at UNDECIDED)

2. STATEMENT / REQUIREMENT FIDELITY
   | TS field | Target (NL) | Artifact | Relation | Note |
   |----------|-------------|----------|----------|------|
   | T2 objects/types | ... | ... | IDENTICAL / ... | |
   | T3 quantifiers   | ... | ... | | |
   | T4 hypotheses    | ... | ... | | |
   | T5 conclusion & quantitative content | ... | ... | | |
   | T6 presuppositions | ... | how well-definedness is proved | | |
   Junk-value audit: <n> sites checked, <m> open
   Non-vacuity witness: <instance or "none - open">
   Lexical diff: <clean | differences>

3. ARGUMENT / DESIGN FIDELITY (T7 = yes|no)
   IDENTICAL n | STRONGER-IN-ARTIFACT n | WEAKER-IN-ARTIFACT n | DIFFERENT-METHOD n | INCOMPARABLE n | UNMAPPED n
   NL steps found false or unjustified: <list or none>
   Compiled/implemented but unused in main chain: <list or none>

4. DEVIATION LOG (summary of all stops)
   | ID | Sev. | Phase | Relation | Artifact | User decision (A/B/C/D) | Status |
   |----|------|-------|----------|----------|-------------------------|--------|
   TS amendments: TS-v1 -> TS-v<k>: <what changed, approved by user>

5. MECHANICAL CHECKS
   Checker accepts: yes/no | Gap markers (sorry/admit/skip/xfail/TODO): <count + list>
   Axioms / assumptions beyond standard: <list>
   Perturbation test: <n> perturbations, <m> survived -> <list>
   Builder-vs-audit map disagreements: <count + list>

6. NOT ESTABLISHED BY THIS VERIFICATION
   - Fidelity is not decidable in general (paper Thm A.3/A.4); this report certifies only that the listed checks found no further deviation.
   - Same-model audit; shares blind spots with the builder.
   - <anything checked only numerically / on a sample / not checked at all>

7. DECISIONS NEEDED FROM THE USER
   - <open items, or "none">
```

---

## Verdict selection (worst applicable wins)

`STATEMENT-CHANGED` > `UNDECIDED` > `NOT PROVEN` > `PROOF-CHANGED` > `FAITHFUL`

- Any open Critical deviation, or any accepted option-B deviation affecting T1-T6 → `STATEMENT-CHANGED`.
- Audit declined, undecidable presupposition, or unproven equivalence → at most `UNDECIDED`.
- Explicit gaps remain → `NOT PROVEN`.
- T7 = yes and any DIFFERENT-METHOD / UNMAPPED / NL-ERROR step accepted → `PROOF-CHANGED` (the user's argument is not validated).
- Only when none of the above holds → `FAITHFUL`.

Note: a TS amendment (option C) changes the target itself; the verdict then refers to TS-v<k>, and the report header must show the version and the amendment line in §4.
