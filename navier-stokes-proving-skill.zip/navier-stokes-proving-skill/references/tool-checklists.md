# Tool checklists - mechanical fidelity checks

**Provenance.** Only the Lean `sInf ∅ = 0` trap and the "no `sorry`, no extra
axioms" success criterion come from the paper (§1, §4.2). Everything else in
this file is a skill-author generalisation of the paper's failure patterns to
other tools. Treat it as an engineering checklist, not as the authors' method.

Run the relevant section in Phase 1 (builder) and again in Phase 4 (audit).
Every hit that is not covered by a proof or an approved deviation becomes a
Deviation Notice.

---

## A. Lean 4 / Mathlib

### A1. Gaps and axioms
- [ ] Search the whole dependency closure (not only the main file) for `sorry`, `admit`, `axiom`, `opaque` with a fake body, `unsafe`, `implemented_by`, `extern`.
- [ ] Run `#print axioms <main_theorem>`. Expected set: `propext`, `Classical.choice`, `Quot.sound`. Anything else (including `sorryAx`, `Lean.ofReduceBool` from `native_decide`) must be listed in the report.
- [ ] Check `set_option` lines that weaken checking (e.g. `maxHeartbeats 0` is harmless; `autoImplicit true` can silently universally quantify a typo'd name - check the statement's binder list).

### A2. Statement fidelity
- [ ] Print the elaborated statement (`#check @main_theorem`) and compare it field by field with TS (T2-T5), not the source text the builder wrote.
- [ ] Quantifier order and scope (`∀ ε, ∃ δ` vs `∃ δ, ∀ ε`); `∀ᵐ` (a.e.) vs `∀`.
- [ ] Interval endpoints: `Icc` / `Ico` / `Ioo`; strict vs non-strict inequalities.
- [ ] Types and coercions: ℕ vs ℤ vs ℝ; casts placed where the NL means a different domain.
- [ ] Every hypothesis in the formal statement appears in T4. Extra hypotheses = `STRONGER-HYP`.
- [ ] Constants: which variables a constant may depend on (the existential's position fixes this).
- [ ] Definitions used in the statement are the intended ones (unfold them; check for local redefinitions shadowing Mathlib names).

### A3. Junk-value traps (presupposition register)
Each occurrence on a path that the statement depends on needs a proof that the
degenerate case cannot occur, or a `JUNK-VALUE` deviation:
- [ ] `sInf`, `sSup`, `iInf`, `iSup` on possibly empty / unbounded sets (`sInf ∅ = 0` on ℕ - paper §4.2).
- [ ] Division and inverse: `x / 0 = 0`, `0⁻¹ = 0`.
- [ ] Truncated subtraction on ℕ (`2 - 5 = 0`).
- [ ] `Nat.find` / `Classical.choose` / `Classical.epsilon` - check the existence proof is genuine.
- [ ] `deriv`, `fderiv`, `integral`, `limUnder`, `tsum` - all return 0 (or a default) when the object does not exist (non-differentiable, non-integrable, non-convergent, non-summable). Require the matching `Differentiable…`, `Integrable…`, `Summable…`, `Tendsto…` facts.
- [ ] `Real.sqrt`, `Real.log`, `Real.rpow` of negative / zero arguments.
- [ ] `default`, `Inhabited` instances, `Option.getD`, `getD`, `get!`.

### A4. Non-vacuity
- [ ] Exhibit a concrete instance satisfying all hypotheses (`example : <hyps for a specific object>`).
- [ ] Check no hypothesis is `False`-equivalent (e.g. contradictory bounds).

### A5. Argument map (when T7 = yes)
- [ ] For each NL step, the corresponding `have`/lemma; compare quantitative content (orders, exponents, series, norm type).
- [ ] Dependency closure of the main theorem; list compiled-but-unused declarations (paper fn. 7).

---

## B. MATLAB (numeric and Symbolic Math Toolbox)

### B1. What a MATLAB run can establish
- [ ] A finite numeric sample never establishes a ∀-statement. If T3 says "for all x in D", numeric evidence alone caps the verdict at `NOT PROVEN` (or the claim is reported as "numerically consistent on <sample>").
- [ ] State the floating-point model: tolerances, `eps`, conditioning. A tolerance chosen after seeing the output is `TEST-WEAKENED`.

### B2. Symbolic checks
- [ ] Declared assumptions (`syms x real`, `assume`, `assumeAlso`) must equal T4 - no extra ones. List them with `assumptions`.
- [ ] `isAlways(cond)` returns `false` both when the condition is false and when it cannot decide (with a warning). Treat "false + warning" as UNDECIDED, not as a disproof; never silence the warning.
- [ ] `simplify` / `solve` may return generic results or drop special cases; use `ReturnConditions=true` for `solve` and check the conditions against T4.
- [ ] Check branch choices (`sqrt`, `log`, `^` with non-integer exponent) match the NL domain.

### B3. Code-level traps
- [ ] `all([])` and `isempty`-guarded checks: an empty test vector passes vacuously.
- [ ] Comparisons with `NaN` are always false; `NaN` outputs can make a "≤" check pass if written as `~(a > b)`.
- [ ] `try/catch` blocks that swallow errors and return a default.
- [ ] `warning('off', …)` around the verification step.
- [ ] `matlab.unittest`: `assumeTrue`/`assumeEqual` mark tests *Incomplete* (filtered), not failed - count them as skipped tests.

---

## C. Wolfram Language / Mathematica / Wolfram|Alpha

### C1. Assumptions and domains
- [ ] `Assumptions` / `$Assumptions` / `Element[x, Reals]` must equal T4; print them.
- [ ] Default domain is complex. Real-variable NL statements need explicit `Reals` assumptions; otherwise the result may be about a different statement.

### C2. Result interpretation
- [ ] `Simplify`/`FullSimplify` returning the input unevaluated means "not shown", not "false".
- [ ] `Solve` returns generic solutions and may omit special cases; prefer `Reduce` for complete case analysis, and check its conditions.
- [ ] `Integrate`/`Limit`/`Sum` with `GenerateConditions -> True`: read the `ConditionalExpression`; dropping it is `SCOPE-NARROWED`.
- [ ] `Limit` direction (`Direction -> "FromAbove"`) must match the NL.
- [ ] `PossibleZeroQ` and numeric `N[...] == 0` are heuristics, not proofs.
- [ ] `Resolve`/`Reduce` with `ForAll`/`Exists` are decision procedures only for supported theories (e.g. real polynomial arithmetic); outside them the result may stay unevaluated.

### C3. Code-level traps
- [ ] `Quiet[...]` or `Off[...]` around the verified expression hides messages that signal failure or branch issues - remove and re-run.
- [ ] `Check[expr, default]` returning a default on failure is a junk value.
- [ ] Wolfram|Alpha natural-language input is re-interpreted; record the "Input interpretation" and diff it against T1 (one-word substitution risk, paper Example 4.4).

---

## D. Software code (any language)

### D1. Requirement traceability
- [ ] Requirement-to-code matrix: every TS item (T1-T6) maps to code units and to at least one test that would fail if the item were violated.
- [ ] Every requirement-level test checks the requirement, not the implementation (tests whose expected values were produced by running the code under test are tautological).
- [ ] Input domain in tests covers the T2/T3 domain, including boundaries and invalid inputs; a narrower generator or fixture set is `SCOPE-NARROWED`.

### D2. Test-suite integrity
- [ ] Count and list `skip`, `xfail`, `@Ignore`, `pending`, `.only`, commented-out tests, `assert True`, tests without assertions.
- [ ] Mocks/stubs: the unit under test must never be mocked; mocked collaborators must be listed.
- [ ] Hard-coded expected outputs or special-casing of test inputs in production code (`if input == fixture: return expected`).
- [ ] Tolerances, timeouts and thresholds equal T5; any loosening after a failure is `TEST-WEAKENED`.
- [ ] Diff the test suite against its state before construction; deleted or weakened tests are deviations.

### D3. Junk-value analogues
- [ ] Broad exception handlers returning defaults (`except Exception: return 0`).
- [ ] Silent fallbacks (`or default`, `?? 0`, `getOrElse`) on paths covered by a requirement.
- [ ] Feature flags or environment checks that bypass the requirement in test environments.

### D4. Design fidelity (when T7 = yes)
- [ ] The specified algorithm / architecture / data flow is the one implemented (e.g. the user asked for an exact solver and got a heuristic; asked for streaming and got batch).
- [ ] Complexity or performance claims in T5 measured, not asserted.

### D5. Perturbation (mutation) test - audit phase
- [ ] Mutate one requirement-relevant element at a time (operator, boundary, constant, removed precondition check). At least one requirement-level test must fail per mutation; survivors are findings.
