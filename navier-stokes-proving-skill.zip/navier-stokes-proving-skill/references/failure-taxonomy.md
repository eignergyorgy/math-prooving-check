# Failure taxonomy (Bastounis, Circelli & Hansen, 2026)

Each pattern lists the paper's example, why the checker cannot catch it, and
the detection cue this skill uses.

## P1 - Wrong NL proof → different, correct formal proof (Example 2.1, §2)

**Example.**
- Claim: p(x) = x³ − x² − x + 1 ≥ 0 for x ≥ −1.
- NL "proof": the roots are −1 (multiplicity two) and 1 (multiplicity one), hence p(x) = (x−1)(x+1)² ≥ 0.
- These multiplicities are wrong. The correct factorisation is (x−1)²(x+1) (skill-author check: x³−x²−x+1 = (x−1)(x²−1); the paper only says the model found the correct multiplicities). The paper also notes the "hence" ignores the leading coefficient (fn. 1).
- Asked to formalise the user's argument, the model produced a correct Lean proof built on the correct factorisation.

**Why the checker misses it.** The formal proof is valid. It just is not the user's proof.

**Detection cue.** Check every NL step independently of the formal artifact. A step that is false in NL but "true" in the artifact means the argument was silently repaired (relation `NL-ERROR`).

## P2 - Correct NL proof → different, correct formal argument (Example 2.2, §2)

**Example.**
- Claim: tr(A²) ≥ 0 for real symmetric A.
- NL proof: diagonalise in an orthonormal eigenbasis and sum λᵢ².
- Lean proof: skips the change of basis, keeps A, and uses a_ji = a_ij to get Σ a_ij² ≥ 0.

**Why the checker misses it.** Both proofs are correct, so nothing fails.

**Detection cue.** Use the step map. The NL step "diagonalise" has no counterpart (`UNMAPPED`), and the closing step uses symmetry instead of diagonality (`DIFFERENT-METHOD`).

## P3 - NL claims more than the formal result (Example 3.1, Remark 3.2, §3.1)

**Example.**
- NL (8.19): ‖N⁻¹F‖_{C^m_y} ≤ C_m ‖F‖_{C^{m+4}_y}.
- Lean `norm_derivativeWord_inverse_le`: hypotheses on (w.length + 5) derivatives, i.e. m+5.
- Cause: the NL argument uses the summable series Σ(1+|k|)⁻³. The Lean route goes through `coefficient_seminorm_bound` with weight⁴, which costs one more derivative.
- The same m+5 pattern recurs in `inverse_finiteJets` and `mixedJet_inverse_bound`.
- Some of these use mixed derivatives, so they are not even comparable with (8.19) (fn. 5).
- To compare at all, a supremum over multi-indices |w| ≤ m is needed, which the declaration does not take (fn. 4).

**Why the checker misses it.** The weaker lemma compiles, and the main theorem may still go through, so nothing flags the gap.

**Detection cue.** For every estimate, compare side by side:
- derivative order;
- exponents and series used;
- norm type (pure torus vs mixed derivatives);
- whether sup/max over indices is taken.

## P4 - Statement and proof both changed (Example 3.3, §3.2)

**Example.**
- NL (10.19): |∫ π w·∇χ_R| ≤ (C_T/R)[(B_R+1)B_R^{1/2} + R^{−3/4}B_R^{3/4}] for a.e. t.
- Lean (`exists_uniform_actual_pressure_flux_bound`): ≤ C_T[(B_R^{1/2}+1)(A_R/R + 1/R²) + R^{−7/4}B_R^{3/4}] for every t.
- Notation: A_R is a localised L² gradient norm; B_R = ‖φ_R⁴ w‖_{L⁶}.
- (10.17) bounds B_R by A_R, so it cannot remove A_R from the Lean bound. The two bounds are hard to compare.

**Method differences (the paper lists three main ones):**
- The Lean proof uses Sobolev embedding and L² boundedness of the Riesz transform, instead of L^{3/2} → L^{3/2} boundedness.
- It applies Hölder's inequality with exponents 6 and 6/5.
- It proves time continuity, which upgrades "a.e. t" to "every t".
- It also splits off φ_R² instead of φ_R⁴, and adds a 12/5 interpolation step that is absent from the NL proof.

**Detection cue.** Check for:
- new quantities in the bound (A_R);
- changed integrability exponents;
- changed quantifier qualifiers (a.e. ↔ every);
- a different cut-off power.

## P5 - Proved but unused results (fn. 7)

**Example.** A bound in `NavierStokes/R3StressPressureEstimate.lean` (part of the definition the paper prints as "regularized flux Bound"; exact identifier not checked against the repo) differs from (10.19). It is compiled, but according to the authors it does not appear to be used to prove the main theorem.

**Detection cue.** Compute the dependency closure of the main theorem and list every formal result outside it. An NL claim that maps only to such a result is effectively unverified.

## P6 - Presupposition hidden by a default value (Examples 4.1-4.2, §4.1-4.2)

**Example.**
- Definition: n_e is the least n such that p_e(n, x) = 0 has no natural-number solution, and r_e = 1/(n_e + 1).
- With p_e = x₁ + x₂ − n, every n has the root (n, 0). So the defining set is empty and r_e is undefined.
- In Lean, `sInf ∅ = 0` gives n_e = 0 and r_e = 1. The identity (r_e+1)² = r_e² + 2r_e + 1 then compiles "by ring".

**Detection cue.** Run the presupposition register. Every `sInf`, `sSup`, division, `Classical.choose`, partial function or default argument must carry a proof that the default case is never used. Otherwise raise a `JUNK-VALUE` deviation.

## P7 - One-word substitution (Example 4.4, §4.3)

**Example.** "Infinitely many odd numbers" mistakenly formalised as "infinitely many primes". Lean compiles, but it is a different theorem.

**Detection cue.** Lexical diff of every predicate and constant against T1.

## P8 - Back-translation used as a fidelity proof (Remark 3.5)

Translating the formal proof back into NL and comparing creates two new fidelity obligations:
- the back-translation must be faithful to the formal proof;
- its reasoning must correspond to the original argument.

So it is as hard as type (ii). Use it only as a signal.

## P9 - AI-verifies-AI at scale (§5.1)

**Example.**
- Meta claimed 26 textbooks were formalised: about 45,000 verified declarations and about 500,000 lines.
- Semantic checking was mainly done by other AIs.
- Lean community members reported fatal mis-formalisations. One reviewer judged 0% of the statements in a book accurately formalised. Another found that the proved items were essentially those already in Mathlib.

**Detection cue.** Never count AI agreement, including this skill's own audit, as a certificate.

## P10 - Compile-driven search loop (§3.4, Example 4.3)

**The loop.** "Revise until the checker accepts" accepts any valid artifact. If the NL proof is wrong, the loop is incentivised to find a different proof. If a definition is ill-posed, the loop can halt on a mistranslation (P6).

**Detection cue.** Re-check the fidelity map after every accepted iteration, not only at the end.
