# Theoretical limits (paper §4.1, Appendix A)

This file explains why the skill cannot promise fidelity and why `UNDECIDED`
is a legitimate verdict. The proofs are in the paper; only the statements and
their operational consequences are recorded here.

## The construction (Example 4.1)

- Fix a computable enumeration (p_e) of integer-coefficient polynomials in k+1 variables.
- B_e(n) :⇔ for all (x₁,…,x_k) ∈ ℕ^k, p_e(n, x₁,…,x_k) ≠ 0.
- n_e := least n with B_e(n), if it exists; r_e := 1/(n_e + 1).
- Any claim about r_e (even the trivial (r_e+1)² = r_e² + 2r_e + 1) can be faithfully formalised only if n_e exists.

## Results

| Result | Statement (paraphrased) |
|---|---|
| Theorem A.3 | For k ≥ 9, the set d = {e : ∃n B_e(n)} is Σ⁰₂-complete. No algorithm decides whether n_e is well-defined, even with an oracle for the Halting problem. |
| Theorem A.4 | With l−2 additional alternating quantifiers, the analogous set d_l is Σ⁰_l-complete for every l ≥ 2; not decidable even with an oracle for ∅^(l−1). |
| Corollary A.5 | SCI_A(Ξ_{d_l}) = l for every l ≥ 2 (arithmetic towers; SCI hierarchy generalises the arithmetical hierarchy, Remark A.2). |
| §A.2.1 | A trustworthy autoformaliser that always outputs either a faithful translation or "cannot be translated" must solve these problems for all l, so the task has SCI = ∞ - informally, it is harder than any computational problem of finite SCI, including the Halting problem (SCI = 1). |
| Remark A.6 | k ≥ 9 reflects the current best DPRM unknowns bound over ℕ (nine-unknown refinement); a recent result lowers the bound over ℤ from 11 to 10. |

Proof tools: the DPRM (Davis–Putnam–Robinson–Matiyasevich) theorem with Jones's nine-unknown refinement, many-one reductions from NTOT, Post's theorem.

## What the authors infer from this

- A semantics-preserving autoformaliser must sometimes refrain from translating, and no AI can always tell when (Remark 4.2, Remark 5.1).
- "Guess and check until the checker accepts" (Example 4.3) can halt on a mistranslation via default values (§4.2).
- Building trustworthy (semantics-preserving) autoformalisers is an open problem; the authors defer their approach to forthcoming work (§4.3).

## Scope caveat (skill author, not the paper)

The undecidability results concern a constructed family of definitions and an
autoformaliser required to answer on *all* inputs. They do not say that any
particular statement the user brings is undecidable. Most practical failures
are the ordinary patterns in `failure-taxonomy.md` (P1-P5, P7), which are
detectable by careful comparison. Use `UNDECIDED` when fidelity is genuinely
not established, not as a default excuse.

## Operational consequences in this skill

1. State the limitation once at the start of every run.
2. Presupposition register (Phase 1): well-definedness must be proved in the artifact, or exposed as an explicit hypothesis (deviation), or the verdict is `UNDECIDED`.
3. No verdict ever claims a guarantee; `FAITHFUL` means "no deviation found by the checks run", and the report lists what was not checked.
4. For high-stakes results, human peer review remains required (paper §1).
