---
name: navier-stokes-proving-skill
description: Enforce semantic fidelity whenever an LLM formalises, proves, verifies or implements what the user asked for (Lean, MATLAB, Wolfram, software code) - lock the exact target, forbid silent problem substitution, stop at every deviation, run a user-approved independent audit, and emit a one-page verification report.
papers: ["Bastounis, Circelli & Hansen, 2026 - Navier-Stokes lost in translation (arXiv:2610.08144v1)"]
version: "1.0.0"
review_status: "ai-generated"
---

# Navier-Stokes Proving Skill - fidelity-first formalisation, proof and implementation

## Core principle

A passing check certifies only the artifact that was checked. Lean compiling,
MATLAB returning `true`, Wolfram simplifying to `True` and a green test suite
all fall under this. None of them shows that the artifact is the thing the
user asked for (Bastounis et al., 2026, §1 "Warning"; §4.3).

The job is to solve **the user's problem as stated**, or to report honestly
that it was not solved:

- A faithful failure is a valid outcome.
- An unfaithful success is a defect.

## When to use

Use this skill when the user asks to:
- prove a theorem, lemma or estimate in Lean 4 (or another proof assistant);
- formalise a natural-language (NL) statement and/or an NL proof;
- verify a mathematical claim symbolically or numerically in MATLAB or Wolfram;
- write software that must meet stated requirements, or a verification harness / test suite for it;
- audit an existing formalisation or codebase against its source (paper, spec, requirement).

Do not use it for explanations that produce no checkable artifact.

## What this skill cannot guarantee (state this once at the start of every run)

Deciding whether an NL definition even denotes a well-defined object can be
undecidable:
- Σ⁰₂-complete for the least-number construction in the paper.
- Undecidable even with a Halting oracle (Theorem A.3).
- Of unbounded arithmetical level (Theorem A.4, Corollary A.5).

So no procedure, including this one, can always decide whether a faithful
translation exists (§4.1, Remark 4.2, Appendix A.2.1). Consequences built
into this skill:
- The verdict `UNDECIDED` is a legitimate output.
- The final authority on statement fidelity is a human reviewer.
- Details are in `references/theoretical-limits.md`.

## Two task types (paper §1) - classify every request

| Type | Paper definition | Success means | Validates the user's own argument? |
|---|---|---|---|
| (i) Proof translation | A faithful formal statement exists; translate an NL proof into a formal proof that compiles, no `sorry`, no extra axioms | Artifact accepted by the checker | **No.** The formal proof may differ from or repair the NL proof |
| (ii) Faithful semantic translation | Translate definitions, statements and proofs (and their dependencies) preserving meaning; a different provable assertion is not faithful | Statement fidelity and argument fidelity, established | Yes, if argument correspondence is established |

Software analogue:
- (i) means "the tests pass".
- (ii) means "the code implements requirement R, by the design the user specified, under the input domain the user specified".

**Rule:** if the user wants to know whether *their* argument or design is
right, the task is type (ii). Never report a type-(i) success as a type-(ii) one.

## Research planning protocol (mandatory before any construction)

1. Restate the goal and classify it as type (i) or (ii).
2. Name the tool(s): Lean / MATLAB / Wolfram / language + test framework.
3. Declare the possible outcomes, including `NOT PROVEN` and `UNDECIDED`.
4. List the known limitations (missing definitions, unspecified domains, ambiguous terms).
5. Present the Target Specification (Phase 0) and **wait for confirmation**.

## Workflow

### Phase 0 - Target Lock

Write a **Target Specification (TS)** from the user's words, not from what is easy to prove.

| Field | Mathematics | Software |
|---|---|---|
| T1 Verbatim target | Statement as given | Requirement as given |
| T2 Objects & types | Spaces, domains, regularity classes, norms | Data types, units, input domain |
| T3 Quantifiers | Order and scope; "for a.e. t" vs "for all t" | "for every input in D" vs a tested sample |
| T4 Hypotheses | All assumptions | Preconditions, environment |
| T5 Conclusion & quantitative content | Derivative orders, exponents, which quantities a constant may depend on, strict vs non-strict | Postconditions, outputs, tolerances, error behaviour, performance bounds |
| T6 Presuppositions | Existence / uniqueness / well-definedness of every defined object | Existence of resources, formats, external guarantees |
| T7 Argument fidelity required? | Must the user's proof route be followed? yes/no | Must the user's design / algorithm be followed? yes/no |
| T8 Success & accepted failure outputs | Proof / disproof / NOT PROVEN / UNDECIDED | Acceptance criteria written by the user, not invented |

Ambiguity:
- List each reading and ask the user to choose.
- Never pick the reading that is easiest to prove or implement.

On approval the TS is frozen as `TS-v1`. Any change makes a new version and
needs the user's explicit approval.

### Phase 1 - Statement / requirement formalisation

1. **One-to-one mapping.** Map every TS field to an element of the formal artifact. Fill the fidelity table (report §2).
2. **Presupposition register.** For every defined object, record how its well-definedness is established in the artifact.
   - Check the default-value traps in `references/tool-checklists.md`. Paper example: Lean `sInf ∅ = 0` silently makes r_e = 1 when n_e does not exist (§4.2).
   - If well-definedness depends on an unsettled fact, do **not** translate with a default.
   - Either add it as an explicit hypothesis (this is a deviation and needs approval), or output `UNDECIDED`.
   - A faithful autoformaliser must sometimes refuse to translate (Remark 4.2, Remark 5.1).
3. **Non-vacuity.** Show the hypotheses are jointly satisfiable by exhibiting an instance. Show that sets the NL assumes non-empty are non-empty.
4. **Lexical diff.** Compare every predicate, constant and operator name with T1. Changing one word ("odd" to "prime") yields a different statement that still compiles (§4.3, Example 4.4).
5. **Literal back-informalisation.** Re-express the formal statement in NL literally, not charitably, and diff it against T1. This is a signal only: back-translation is itself as hard as type (ii) (Remark 3.5).

Any mismatch triggers the **deviation-stop protocol**.

### Phase 2 - Construction with a fidelity map

- When T7 = yes, split the NL proof (or design) into numbered steps S1..Sn and map each to a formal declaration or code unit.
- Status per step: `IDENTICAL`, `STRONGER-IN-ARTIFACT`, `WEAKER-IN-ARTIFACT`, `DIFFERENT-METHOD`, `INCOMPARABLE`, `UNMAPPED`.
- Record quantitative content side by side for each step:
  - derivative order,
  - exponents and Hölder pairs,
  - norm type (pure vs mixed derivatives),
  - constant dependencies,
  - a.e. vs every,
  - extra quantities that appear (e.g. A_R in Example 3.3).
- The guess-and-check loop (§3.4) accepts any valid artifact. It rewards repairing or replacing the argument. So **re-check the map after every successful compile or test run**, not only at the end.
- **The NL step is false or unjustified** (Example 2.1):
  - Do not fix it silently.
  - Report the failing step and why, then stop (deviation-stop protocol).
- **Stuck:**
  - Leave an explicit gap (`sorry`, `TODO`, a failing test) and report it.
  - Never substitute an easier or already-solved problem.
- **Inventory both directions:**
  - formal results proved but never used in the main chain (paper fn. 7);
  - NL claims with no formal counterpart.

### Phase 3 - Hard rules (forbidden without explicit user approval)

| ID | Forbidden act |
|---|---|
| F1 | Changing the statement or requirement: weaker, stronger or different |
| F2 | Replacing the target with a solved, easier or more tractable problem |
| F3 | Adding hypotheses, axioms or gap markers (`sorry`, `admit`, `axiom`, skipped tests) without disclosure |
| F4 | Using default / junk values to define an object whose well-definedness is part of the claim |
| F5 | Silently repairing the user's argument or design |
| F6 | Changing the method when T7 = yes |
| F7 | Weakening tests, tolerances or acceptance criteria; mocking the unit under test; narrowing the input domain; hard-coding expected outputs |
| F8 | Changing quantifier qualifiers (a.e. ↔ every) or constant dependencies without recording it |
| F9 | Reporting "verified" when only compilation or tests passed |
| F10 | Treating agreement between AI systems as evidence of fidelity (Meta case, §5.1) |

### Deviation-stop protocol (applies in every phase, including the audit)

On detection:
1. **Stop** all further construction (this saves tokens).
2. Emit a Deviation Notice.
3. Wait for the user.

Every deviation also goes into the **Deviation Log**, which is summarised in
the final report.

```
DEVIATION D<n> - <Critical|Major|Minor> - Phase <p>
Target (TS-v<k>): <field + exact text>
Artifact: <file:line / declaration / function>
Relation: STRONGER-HYP | WEAKER-CONCL | DIFFERENT-STATEMENT | DIFFERENT-METHOD |
          JUNK-VALUE | VACUOUS | NL-ERROR | UNMAPPED | SCOPE-NARROWED | TEST-WEAKENED
Consequence: <what the artifact does NOT establish>
Options:
  A - retry faithfully (no change to TS)
  B - accept as labelled deviation (artifact no longer proves TS-v<k>)
  C - amend the target (creates TS-v<k+1>, your explicit wording)
  D - stop; verdict NOT PROVEN / UNDECIDED
Waiting for your decision.
```

Severity levels:
- **Critical:** the statement or requirement changed, or a success claim would be false.
- **Major:** the method changed while T7 = yes, or a quantitative parameter of an intermediate result differs.
- **Minor:** representation or notation differs and the equivalence is not yet proved.

### Phase 4 - Independent audit (mandatory, permission-gated)

**Permission.** Before running, ask exactly once per audit:

> "Run the independent audit now? It re-derives the fidelity map from TS-v<k>
> and the final artifacts only (scope: <n> declarations / files)."

Wait for the answer. If the user declines, the verdict is capped at
`UNDECIDED` and the report states that the audit was not run.

**Audit rules (same session, separate step):**
- Inputs are restricted to TS-v<k>, the source NL text and the final artifacts. Do not reuse the builder's reasoning or fidelity map as evidence.
- Rebuild the fidelity map from scratch, then diff it against the builder's map. Each disagreement is a finding.
- Take an adversarial stance: the default hypothesis is that a mistranslation exists, and the audit tries to locate it.
- Run the mechanical checks in `references/tool-checklists.md` for every tool used.
- Literally back-informalise the main statement and every mapped intermediate result.
- **Perturbation test:**
  - Weaken one hypothesis or change one constant, one at a time.
  - The artifact should then fail wherever the TS says the item matters.
  - Survival flags a vacuous or unused hypothesis.
- Route every finding through the deviation-stop protocol.
- State the limitation in the report: a same-model audit shares blind spots with the builder. For high-stakes results, require the same human peer review applied to any proof (§1).

### Phase 5 - Verdict and report

| Verdict | Condition |
|---|---|
| `FAITHFUL` | Statement fidelity confirmed, argument fidelity confirmed (if T7 = yes), mechanical checks clean, audit run, no open deviations. Means "no deviation found by the checks run" - never a guarantee |
| `PROOF-CHANGED` | The target is proved or implemented faithfully, but by a different argument or design. The user's NL argument is **not** validated |
| `STATEMENT-CHANGED` | The artifact establishes something other than TS. Never present it as a proof or implementation of TS |
| `UNDECIDED` | Fidelity cannot be established: undecidable presupposition, audit declined, or equivalence unproven |
| `NOT PROVEN` | A faithful attempt failed. Gaps are listed. This is a valid result |

Precedence when several apply (worst wins):
`STATEMENT-CHANGED` > `UNDECIDED` > `NOT PROVEN` > `PROOF-CHANGED` > `FAITHFUL`.

The report must fit one page. Use `references/verification-report-template.md`.

## Mathematics ↔ software correspondence

| Proof setting | Software setting |
|---|---|
| Statement | Requirement / specification |
| Hypotheses | Preconditions, input domain, environment |
| Conclusion | Postconditions, outputs, tolerances |
| User's NL proof route | User-specified design / algorithm |
| "Lean compiles" | "Tests pass" |
| Junk / default value (`sInf ∅ = 0`) | Silent fallback, default return, swallowed exception |
| `sorry` / extra axiom | `TODO`, `skip`/`xfail`, mock or stub of the unit under test, hard-coded fixture |
| Weaker formal lemma (m+5 vs m+4) | Looser tolerance, narrower supported input range |

## Failure patterns to look for

Full descriptions with the paper's examples and detection cues are in
`references/failure-taxonomy.md`:

- P1 wrong NL proof turned into a different, correct formal proof (Ex. 2.1)
- P2 correct NL proof turned into a different, correct argument (Ex. 2.2)
- P3 NL claims more than the formal result (Ex. 3.1, Remark 3.2)
- P4 statement and proof both changed (Ex. 3.3)
- P5 formal results proved but unused (fn. 7)
- P6 presupposition hidden by default values (Ex. 4.1-4.2)
- P7 one-word substitution (Ex. 4.4)
- P8 back-translation taken as proof of fidelity (Remark 3.5)
- P9 AI-verifies-AI at scale (Meta case, §5.1)
- P10 compile-driven search loop (§3.4, Ex. 4.3)

## Missing information

- **Operational detection procedure at scale:** Not reported. Remark 3.4 points to an external experiment that is not reproduced in the paper.
- **Construction of a trustworthy autoformaliser:** Not reported. The authors defer it to forthcoming work (§4.3).
- **Quantitative thresholds** (acceptable mismatch rates, audit depth): Not reported. This skill uses zero tolerance for unapproved deviations.
- **MATLAB, Wolfram and software-code procedures:** Not in the paper. They are generalised by the skill author (see below).
- **`research-literacy` dependency:** Expected by the generator template, but not available in this environment. Omitted.

## Deviations from convention

- **Acceptance criterion:** The usual criterion "the checker accepts the artifact" is replaced by verified statement fidelity, plus argument fidelity when required. The authors argue that compilation says nothing about the NL proof (§1, §3.4).
- **Not from the paper (skill-author additions):**
  - Tool checklists for Lean `#print axioms`, MATLAB, Wolfram and code.
  - The perturbation test.
  - The verdict labels.
  - The deviation severity scale.
  - The software correspondence table.
  - The precedence rule.

  These are engineering choices, not the authors' prescriptions.

## Background (case study in the paper, §3, §5)

**Navier-Stokes case.** The authors examine OpenAI's announced finite-time
blow-up proof for Navier-Stokes and its Lean repository (commit f9e8bc5):
- The inverse estimate (8.19) uses m+4 derivatives in the NL paper, but the Lean declarations use m+5.
- The pressure-flux bound (10.19) is replaced in Lean by a bound with extra A_R dependence, proved by a different argument.
- They predict similar issues for the companion Euler result, based on preliminary examination.
- They make no claim about whether the NL proof itself is correct.

**Other context cited:**
- Meta's 26-textbook autoformalisation claim, disputed by Lean community members.
- The Leiden Declaration (June 2026).
- A Fields-medalist declaration (September 2026).
- A 13-million-line Lean autoformalisation of Fermat's Last Theorem (Anthropic), cited as evidence that output size will make manual checking ever harder.
